#include <stdio.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <time.h>

int main() {

    gsl_rng* rng = gsl_rng_alloc(gsl_rng_default);

    gsl_rng_set(rng, time(NULL)); // Set a seed for reproducibility
    printf("Hello, World!\n");

    
    for(int i=0;i<100000;++i){
        double x =gsl_ran_exponential(rng,5); // Generate a random number (for demonstration)
        printf("Random number: %f\n", x);
    }
    gsl_rng_free(rng);
    return 0;
}